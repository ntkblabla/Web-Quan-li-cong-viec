export type FolderType = {
  id?: number;
  name: string;
  spaceId?: number;
};
