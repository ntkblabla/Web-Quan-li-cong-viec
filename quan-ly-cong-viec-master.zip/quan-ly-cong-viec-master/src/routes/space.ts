import express from 'express';
import space from '../modules/space/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();

router.get('/workspaces/:workspaceId/spaces', asyncMiddleware(space.getSpacesByWorkspaceId));
router.post('/workspaces/:workspaceId/spaces', asyncMiddleware(space.create));

export default router;
