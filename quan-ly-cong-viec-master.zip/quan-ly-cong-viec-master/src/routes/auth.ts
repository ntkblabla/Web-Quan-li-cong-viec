import express from 'express';
import auth from '../modules/auth/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();

router.post('/auth/register', asyncMiddleware(auth.register));
router.post('/auth/login', asyncMiddleware(auth.login));
router.post('/users/:id', asyncMiddleware(auth.updateUserInfo));
router.get('/me', asyncMiddleware(auth.getUserInfo));

export default router;
