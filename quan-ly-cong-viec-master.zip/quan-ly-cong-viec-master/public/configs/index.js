const configs = {
  baserUrl: `http://localhost:8010`,
};

export default configs;
