export type UserWorkspaceType = {
  id: number;
  userId: number;
  workspaceId: number;
};
