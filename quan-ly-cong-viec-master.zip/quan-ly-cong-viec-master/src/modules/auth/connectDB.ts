import { createConnection } from 'typeorm';

const connectDB = createConnection();

export default connectDB;
