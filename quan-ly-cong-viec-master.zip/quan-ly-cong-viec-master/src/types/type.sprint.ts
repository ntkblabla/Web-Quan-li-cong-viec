export type SprintType = {
  id?: number;
  index?: number;
  startAt: Date;
  endAt: Date;
  status: string;
  name: string;
  folderId: number;
};
