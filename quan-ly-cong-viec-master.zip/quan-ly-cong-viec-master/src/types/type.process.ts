export type ProcessType = {
  id?: number;
  name: string;
  color: string;
  order: number;
  isCompleted: boolean;
  spaceId?: number;
};
