export type WorkspaceType = {
  id?: number;
  name: string;
  color: string;
};
