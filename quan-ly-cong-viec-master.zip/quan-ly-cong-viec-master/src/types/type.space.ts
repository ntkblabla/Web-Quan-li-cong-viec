export type SpaceType = {
  id?: number;
  name: string;
  color: string;
  workspaceId: string;
};
