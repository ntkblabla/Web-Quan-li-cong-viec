import express from 'express';
import task from '../modules/task/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();
router.post('/sprints/:sprintId/tasks', asyncMiddleware(task.create));
router.get('/spaces/:spaceId/sprints/:sprintId/tasks', asyncMiddleware(task.getTasksBySprintId));
router.post('/tasks/:taskId/users/:userId', asyncMiddleware(task.updateUserTask));
router.put('/tasks/:taskId', asyncMiddleware(task.update));
router.put('/tasks/:taskId/users/clear', asyncMiddleware(task.clearUserTask));
router.get('/tasks/:taskId', asyncMiddleware(task.getTasksById));

export default router;
