import express from 'express';
import process from '../modules/process/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();

router.post('/processes', asyncMiddleware(process.create));
router.post('/processes/:id', asyncMiddleware(process.update));
router.get('/spaces/:spaceId/processes', asyncMiddleware(process.getListBySpaceId));

export default router;
