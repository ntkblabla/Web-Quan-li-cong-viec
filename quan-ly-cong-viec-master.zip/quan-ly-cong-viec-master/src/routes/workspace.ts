import express from 'express';
import asyncMiddleware from '../middlewares/async';
import workspaceControllers from '../modules/workspace/controllers';

const router = express.Router();

router.post('/workspaces', asyncMiddleware(workspaceControllers.create));
router.post('/users/:userId/workspaces/:workspaceId', asyncMiddleware(workspaceControllers.update));
router.get('/users/:userId/workspaces', asyncMiddleware(workspaceControllers.getByUserId));
router.get('/workspaces/:workspaceId/users', asyncMiddleware(workspaceControllers.getMemberWorkspace));
router.post('/workspaces/:workspaceId/members', asyncMiddleware(workspaceControllers.addMemberToWorkspace));

export default router;
