import express from 'express';
import sprint from '../modules/sprint/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();

router.get('/folders/:folderId/sprints', asyncMiddleware(sprint.getFolderByFolderId));
router.post('/folders/:folderId/sprints', asyncMiddleware(sprint.create));

export default router;
