import express from 'express';
import folder from '../modules/folder/controllers';
import asyncMiddleware from '../middlewares/async';

const router = express.Router();

router.get('/spaces/:spaceId/folders/:folderId', asyncMiddleware(folder.getFolderById));
router.post('/spaces/:spaceId/folders/', asyncMiddleware(folder.create));
router.post('/spaces/:spaceId/folders/:folderId', asyncMiddleware(folder.update));

export default router;
